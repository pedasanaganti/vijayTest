from flask import Flask, jsonify, request
import json
import os

app = Flask(__name__)

# Path to the ratings JSON file
ratings_file_path = os.path.join(os.path.dirname(__file__), '../public/ratings.json')

# Ensure the JSON file exists
if not os.path.exists(ratings_file_path):
    with open(ratings_file_path, 'w') as file:
        json.dump({}, file)

# Endpoint to get ratings for a specific user
@app.route('/api/ratings/<user_id>', methods=['GET'])
def get_user_ratings(user_id):
    try:
        with open(ratings_file_path, 'r') as file:
            ratings = json.load(file)
        user_ratings = ratings.get(user_id, {})
        return jsonify(user_ratings)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Endpoint to add or update a rating for a specific tool by a user
@app.route('/api/ratings/<user_id>', methods=['POST'])
def add_or_update_rating(user_id):
    try:
        # Read the current data
        with open(ratings_file_path, 'r') as file:
            ratings = json.load(file)

        # Update the rating
        data = request.get_json()
        tool_id = data.get("toolId")
        rating = data.get("rating")

        if not tool_id or rating is None:
            return jsonify({"error": "toolId and rating are required"}), 400

        # Update or add the user's rating for this tool
        if user_id not in ratings:
            ratings[user_id] = {}
        ratings[user_id][tool_id] = rating

        # Write back to the JSON file
        with open(ratings_file_path, 'w') as file:
            json.dump(ratings, file, indent=2)

        return jsonify({"message": "Rating saved successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)
