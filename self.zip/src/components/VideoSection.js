import React from 'react';

const VideoSection = () => {
  return (
    <section className="video-section">
      <h2>Futurepedia is on YouTube</h2>
      <div className="video-placeholder">[YouTube Video Placeholder]</div>
    </section>
  );
};

export default VideoSection;
