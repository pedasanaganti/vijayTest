import React from 'react';

const HeroSection = () => {
  return (
    <section className="hero-section">
      <h1>Welcome back, Vijaya</h1>
      <p>Here’s a new way to browse!</p>
      <button>Discover New Tools</button>
    </section>
  );
};

export default HeroSection;
