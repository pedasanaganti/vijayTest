import React from 'react';

const TrendingCategories = () => {
  const categories = ["Marketing", "Productivity", "Design", "Video", "Research"];

  return (
    <section className="trending-categories">
      <h2>Trending Categories</h2>
      <div className="category-list">
        {categories.map((category, index) => (
          <div key={index} className="category">
            {category}
          </div>
        ))}
      </div>
    </section>
  );
};

export default TrendingCategories;
