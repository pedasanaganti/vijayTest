import React, { useEffect, useState } from 'react';

const Sidebar = ({ onCategorySelect, selectedCategory }) => {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch('/categories.json')
      .then(response => response.json())
      .then(data => setCategories(data.categories))
      .catch(error => console.error("Error fetching categories:", error));
  }, []);

  return (
    <aside className="sidebar">
      <h2>Most Popular AI Tools By Business Function</h2>
      <ul>
        {categories.map((category, index) => {
          const formattedCategory = category.toLowerCase().replace(/&/g, "_").replace(/ /g, "_");
          return (
            <li key={index}>
              <a
                href="#"
                className={selectedCategory === formattedCategory ? 'active' : ''}
                onClick={(e) => {
                  e.preventDefault();
                  onCategorySelect(formattedCategory); // Send formatted category
                }}
              >
                {category}
              </a>
            </li>
          );
        })}
      </ul>
    </aside>
  );
};

export default Sidebar;