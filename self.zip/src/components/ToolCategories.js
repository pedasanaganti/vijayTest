import React from 'react';

const ToolCategories = () => {
  const categories = ["AI Image Tools", "AI Business Tools", "AI Code Tools", "AI Generators", "AI Video Tools"];

  return (
    <section className="tool-categories">
      <h2>AI Tool Categories</h2>
      <div className="category-grid">
        {categories.map((category, index) => (
          <div key={index} className="category-card">
            {category}
          </div>
        ))}
      </div>
    </section>
  );
};

export default ToolCategories;
