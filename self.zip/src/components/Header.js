import React from 'react';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">Futurepedia</div>
      <nav>
        <a href="#all-tools">All Tools</a>
        <a href="#categories">Categories</a>
        <a href="#resources">Resources</a>
      </nav>
      <div className="user-info">Welcome back, Vijaya</div>
    </header>
  );
};

export default Header;
