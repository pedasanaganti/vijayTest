import React, { useEffect, useState } from 'react';
import axios from 'axios';

const userId = "user123";

const ToolSection = ({ selectedCategory }) => {
  const [tools, setTools] = useState([]);
  const [userRatings, setUserRatings] = useState({});

  useEffect(() => {
    fetch('/tools.json')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => setTools(data.tools))
      .catch(error => console.error("Error fetching tools:", error));

    axios.get(`http://localhost:5000/api/ratings/${userId}`)
      .then(response => setUserRatings(response.data))
      .catch(error => console.error("Error fetching user ratings:", error));
  }, []);

  const handleRatingSubmit = (toolId, newRating) => {
    setUserRatings(prevRatings => ({
      ...prevRatings,
      [toolId]: newRating
    }));

    axios.post(`http://localhost:5000/api/ratings/${userId}`, { toolId, rating: newRating })
      .then(response => console.log(response.data.message))
      .catch(error => console.error("Error saving rating:", error));
  };

  const filteredTools = selectedCategory === "most_popular_ai_tools_by_business_function"
    ? tools
    : tools.filter(tool => tool.tags.includes(selectedCategory));

  return (
    <section className="tool-section">
      <h2>{selectedCategory.replace(/_/g, " ").toUpperCase()}</h2>
      <div className="tool-grid">
        {filteredTools.length > 0 ? (
          filteredTools.map((tool, index) => (
            <div key={index} className="tool-card">
              <h3>{tool.name}</h3>
              <div className="tool-rating">
                <span>{'★'.repeat(Math.round(tool.rating || 0))}</span>
                <span> ({tool.rating ? 1 : 0} review)</span>
              </div>
              <p>{tool.description}</p>
              <p className="tool-price">
                {tool.price} - <strong>{tool.cost}</strong>
              </p>
              <div className="tool-tags">
                {tool.tags.map((tag, tagIndex) => (
                  <span key={tagIndex} className="tool-tag">#{tag}</span>
                ))}
              </div>
              <button className="tool-cta">{tool.ctaText}</button>

              <div className="rating-input">
                <label htmlFor={`rating-${index}`}>Your Rating:</label>
                <select
                  id={`rating-${index}`}
                  value={userRatings[tool.name] || ""}
                  onChange={(e) => handleRatingSubmit(tool.name, parseInt(e.target.value))}
                >
                  <option value="">Rate...</option>
                  {[1, 2, 3, 4, 5].map(ratingValue => (
                    <option key={ratingValue} value={ratingValue}>{ratingValue}</option>
                  ))}
                </select>
              </div>
            </div>
          ))
        ) : (
          <p>No tools available for this category.</p>
        )}
      </div>
    </section>
  );
};

export default ToolSection;