import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import HeroSection from './components/HeroSection';
import ToolSection from './components/ToolSection';
import TrendingCategories from './components/TrendingCategories';
import VideoSection from './components/VideoSection';
import ToolCategories from './components/ToolCategories';
import Footer from './components/Footer';
import './styles.css';

function App() {
  // Manage the selected category state
  const [selectedCategory, setSelectedCategory] = useState("Most Popular AI Tools By Business Function");

  return (
    <div className="App">
      <Header />
      <div className="main-container">
        {/* Pass the selectedCategory and setSelectedCategory to Sidebar */}
        <Sidebar onCategorySelect={setSelectedCategory} selectedCategory={selectedCategory} />
        <div className="content">
          <HeroSection />
          {/* Pass selectedCategory to ToolSection */}
          <ToolSection selectedCategory={selectedCategory} />
          <TrendingCategories />
          <VideoSection />
          <ToolCategories />
          <Footer />
        </div>
      </div>
    </div>
  );
}

export default App;